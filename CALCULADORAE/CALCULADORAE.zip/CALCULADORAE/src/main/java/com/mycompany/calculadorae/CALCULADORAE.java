/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadorae;

/**
 *
 * @author sanmg
 */
public class CALCULADORAE {

    public static void main(String[] args) {
        TelaPrincipal a = new TelaPrincipal();
        a.setVisible(true);
             
    }
}
